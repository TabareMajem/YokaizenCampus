import { AppDataSource } from './database';

export default AppDataSource;
