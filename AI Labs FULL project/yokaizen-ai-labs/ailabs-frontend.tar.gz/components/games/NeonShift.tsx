
import React from 'react';

export const NeonShift: React.FC<any> = () => {
  return <div className="text-white p-4">Game Module Disabled</div>;
};
